<?php
    require_once('ParergonThemePlugin.inc.php');
    return new ParergonThemePlugin();
?>
